(window.webpackJsonp=window.webpackJsonp||[]).push([[63],{1660:function(n,e,t){t(47)({target:"Number",stat:!0},{isInteger:t(551)})}}]);
//# sourceMappingURL=63.chunk.js.map